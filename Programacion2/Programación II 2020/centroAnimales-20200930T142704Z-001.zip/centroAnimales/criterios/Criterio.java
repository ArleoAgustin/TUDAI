package centroAnimales.criterios;

import centroAnimales.Jaula;

public abstract class Criterio {
    public abstract boolean cumple(Jaula j);
}
